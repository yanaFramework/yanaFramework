CREATE TABLE IF NOT EXISTS `guestbook` (
	`guestbook_id` INT(8) NOT NULL AUTO_INCREMENT,
	`profile_id` VARCHAR(128) NOT NULL,
	`guestbook_ip` VARCHAR(15) NOT NULL,
	`guestbook_name` VARCHAR(128) NOT NULL COMMENT '%LANGUAGE.21%',
	`guestbook_message` TEXT NOT NULL COMMENT '%LANGUAGE.8%',
	`guestbook_mail` VARCHAR(255) NULL COMMENT 'E-Mail',
	`guestbook_hometown` VARCHAR(100) NULL COMMENT '%LANGUAGE.4%',
	`guestbook_homepage` VARCHAR(512) NULL COMMENT '%LANGUAGE.2%',
	`guestbook_messenger` VARCHAR(255) NULL COMMENT 'Messenger',
	`guestbook_msgtyp` TEXT NULL COMMENT 'Typ',
	`guestbook_opinion` TEXT NULL COMMENT '%LANGUAGE.RATE_0%',
	`guestbook_date` INT(11) NOT NULL COMMENT '%LANGUAGE.DATE_TIME%',
	`guestbook_comment` TEXT NULL COMMENT '%LANGUAGE.5%',
	`guestbook_is_registered` INT(1) NULL DEFAULT '0',
	PRIMARY KEY  (`guestbook_id`)
) TYPE=MyISAM;INSERT INTO `guestbook` (`guestbook_name`, `guestbook_message`, `profile_id`, `guestbook_ip`, `guestbook_date`, `guestbook_hometown`, `guestbook_homepage`, `guestbook_id`) VALUES ('Tom', '[h]Herzlich Willkommen![/h] Das ist dein neues G&auml;stebuch mit dem Besucher deiner Webseite dir Nachrichten hinterlassen k�nnen. Dir stehen [color=red]viele Funktionen[/color] zur Verf�gung, wie Smilies :bigsmile: oder [b][big]Text[/big][i]format[small]ierung[/small][/i][/b].[br] [br]Ausserdem besitzt dieses G&auml;stebuch eine [mark]Multi-User Umgebung[/mark]. Alle deine Freunde k&ouml;nnen bei dir ein eigenes G&auml;stebuch bekommen.[br] [br]Du hast eine Mailbenachrichtigung bei neuen Eintr&auml;gen und die M�glichkeit [mark]individuelle Skins[/mark] zu gestalten.[br] [br] [b]:problem: Ein kleines Geheimnis:[/b][hide] Auf unserer Homepage gibt es kostenlos Plugins zum Download, mit denen man sein G�stebuch mit neuen Funktionen aufpeppen kann. F�r Communities gibt es zum Beispiel eine Rechteverwaltung f�r angemeldete Nutzer und vieles mehr![/hide] [br] [c]:haus: kostenlose Updates findest du auf [url=www.yanaframework.net]unserer Homepage[/url][/c]', 'default', '127.0.0.1', '1142975124', 'Jena', 'www.yanaframework.net', 1);