CREATE TABLE IF NOT EXISTS `microsummary` (
	`microsummary_id` VARCHAR(32) NOT NULL COMMENT 'ID',
	`microsummary_text` TEXT NOT NULL COMMENT 'Microsummary',
	PRIMARY KEY  (`microsummary_id`)
) TYPE=MyISAM;