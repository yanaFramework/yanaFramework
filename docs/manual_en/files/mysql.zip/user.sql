CREATE TABLE IF NOT EXISTS `usergroup` (
	`group_id` VARCHAR(32) NOT NULL,
	`group_value` INT(3) NOT NULL DEFAULT '0',
	`group_name` VARCHAR(64) NOT NULL,
	PRIMARY KEY  (`group_id`)
) TYPE=InnoDB;CREATE TABLE IF NOT EXISTS `user` (
	`user_id` VARCHAR(32) NOT NULL COMMENT '%LANGUAGE.USER.OPTION.0%',
	`inserted` INT(11) NOT NULL,
	`modified` INT(11) NULL,
	`user_pwd` VARCHAR(128) NOT NULL DEFAULT 'UNINITIALIZED',
	`user_mail` VARCHAR(255) NOT NULL COMMENT '%LANGUAGE.USER.OPTION.5%',
	`user_gender` TEXT NULL COMMENT '%LANGUAGE.USER.OPTION.19%',
	`group_id` VARCHAR(32) NOT NULL COMMENT '%LANGUAGE.USER.OPTION.1%',
	`active` BOOL NOT NULL DEFAULT true COMMENT '%LANGUAGE.USER.OPTION.3%',
	`user_language` VARCHAR(32) NULL,
	`user_image` VARCHAR(128) NULL COMMENT '%LANGUAGE.USER.OPTION.6%',
	`user_image_active` BOOL NULL DEFAULT false COMMENT '%LANGUAGE.USER.24%',
	`user_failure_count` INT(1) NULL DEFAULT '0',
	`user_failure_time` INT(11) NULL,
	`count_logins` INT NULL DEFAULT '0',
	`last_login` INT(11) NULL,
	`user_description` TEXT NULL COMMENT '%LANGUAGE.USER.OPTION.17%',
	PRIMARY KEY  (`user_id`)
) TYPE=InnoDB;CREATE TABLE IF NOT EXISTS `useraccess` (
	`access_id` INT NOT NULL AUTO_INCREMENT,
	`user_id` VARCHAR(32) NOT NULL COMMENT '%LANGUAGE.USER.OPTION.0%',
	`group_id` VARCHAR(32) NOT NULL COMMENT '%LANGUAGE.USER.OPTION.2%',
	`profile_id` VARCHAR(32) NOT NULL COMMENT '%LANGUAGE.PROFILE_ID%',
	PRIMARY KEY  (`access_id`)
) TYPE=InnoDB;CREATE TABLE IF NOT EXISTS `newuser` (
	`newuser_id` INT(5) NOT NULL AUTO_INCREMENT,
	`newuser_key` TEXT NOT NULL,
	`newuser_mail` VARCHAR(255) NOT NULL,
	`newuser_name` VARCHAR(32) NOT NULL,
	`newuser_utc` INT(11) NOT NULL,
	`newuser_ip` VARCHAR(15) NOT NULL,
	PRIMARY KEY  (`newuser_id`)
) TYPE=MyISAM;ALTER TABLE `user` ADD FOREIGN KEY (`group_id`) REFERENCES `usergroup` (`group_id`);ALTER TABLE `useraccess` ADD FOREIGN KEY (`group_id`) REFERENCES `usergroup` (`group_id`);ALTER TABLE `useraccess` ADD FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (-1, '%LANGUAGE.GROUPS.0%', 'BLOCKED');INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (0, '%LANGUAGE.GROUPS.1%', 'GUEST');INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (1, '%LANGUAGE.GROUPS.5%', 'REGISTERED');INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (30, '%LANGUAGE.GROUPS.2%', 'MOD');INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (75, '%LANGUAGE.GROUPS.3%', 'OWNER');INSERT INTO `usergroup` (`group_value`, `group_name`, `group_id`) VALUES (100, '%LANGUAGE.GROUPS.4%', 'ADMIN');INSERT INTO `user` (`user_pwd`, `group_id`, `active`, `inserted`, `user_description`, `last_login`, `count_logins`, `modified`, `user_mail`, `user_image_active`, `user_id`) VALUES ('UNINITIALIZED', 'ADMIN', 1, '1110324851', 'Das ist ein vordefiniertes Nutzerkonto f�r den Administrator des Programms.[br] [br][c]Dieses Konto kann nicht gel�scht werden.[/c]', '1110324851', 1, '1110324851', 'mail@domain.tld', 0, 'ADMINISTRATOR');