<?php
/**
 * Yana Plugin "blog"
 *
 * 
 *
 * @author      Thomas Meyer
 *
 * @package     plugin
 */

/**
 * �plugin� class "plugin_blog"
 *
 * @access      public
 * @package     plugin
 */
class plugin_blog extends plugin
{

    /**
     * Connection to data source (API)
     *
     * Is created by a factory function and can be either a connection to "some" database or a text-file,
     * depending on user settings. The correct type will be determined automatically. Take a look at the
     * documentation of class 'DbStream' for details on this API. (all alternative classes implement
     * the same interface, regardless whether the source is a file or a databse)
     *
     * {@internal
     *
     * NOTE:
     * As of PHP 5 the notation "var $database" became deprecated, resulting in an E_STRICT_NOTICE.
     * So you may want to change this to "private $database" for PHP 5. Just be aware that doing so will
     * break backwards compatibility with PHP 4.
     *
     * }}
     *
     * @access  private
     * @var     object serializeableObject  Database-API with Query-Builder (also works with text-files)
     *
     * @ignore
     */
    var $database;

    /**
     * Constructor
     *
     * @access  public
     * @name    plugin_blog::__construct()
     * @param   string  $name  a name for this plugin
     */
    function plugin_blog($name)
    {
        assert('is_string($name);');

        $this->name = $name;
        global $YANA;
        $this->database = $YANA->connect("blog");
    }


/* BEGIN custom Event-handlers */

    /* NOTE:
     * All member-functions stated here act as action handlers
     * (event handlers) and may be called directly in a browser
     * by typing index.php?action=function_name
     *
     * (you may exclude a single function from this behaviour by
     * starting it's name with an underscore '_')
     *
     * While it is not required by default, it is thus highly
     * recommended that you specify all functions within
     * the "INTERFACE"-section of your plugin.config.
     * Refer to the manual for details.
     *
     * For security reasons you may want to override this behaviour
     * to deny access by default if no "INTERFACE"-section AND
     * "INTERFACE.function_name.PERMISSION" entry is provided
     * by setting "DEFAULT.EVENT.PERMISSION" to "-1" in the
     * config/system.config file.
     * Note that this might break up some plugins!
     * As an alternative: setting the value to "1" will require
     * users to be at least registered and logged in to be able
     * to call "unprotected" functions.
     */


/* END custom Event-handlers */

/* BEGIN auto-generated Event-handlers */


    /**
     * blog_read_edit_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        read
     * Permission:  75
     * Templates:   BLOG_EDIT_BLOG
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_read_edit_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_read_edit_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;

        /* do something */
        return true;
    }


    /**
     * blog_write_edit_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        write
     * Permission:  75
     * Templates:   MESSAGE 
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_write_edit_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_write_edit_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;


        $updatedEntries = GuiCreator::getFormdata(GUI_EDIT, $this->database->structure, 'blog');

        /* no data has been provided */
        if (empty($updatedEntries)) {
            $YANA->report(new Warning('ungueltige_eingabe'));
            return false;
        }

        foreach ($updatedEntries as $id => $entry)
        {
            $id = strtolower($id);

            /* before doing anything, check if entry exists */
            if (!$this->database->exists("blog.${id}")) {

                /* error - no such entry */
                $YANA->report(new Warning('ungueltige_eingabe'));
                return false;

            /* update the row */
            } else if (!$this->database->insert("blog.${id}", $entry)) {
                /* error - unable to perform update - possibly readonly */
                return false;
            }
        } /* end for */
        /* commit changes */
        return $this->database->write();
    }


    /**
     * blog_write_delete_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        write
     * Permission:  75
     * Templates:   MESSAGE 
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_write_delete_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_write_delete_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;

        /* check if user forgot to mark at least 1 row */
        if (empty($ARGS['selected_entries']) || !is_array($ARGS['selected_entries'])) {
            $YANA->report(new warning('ungueltige_eingabe'));
            return false;
        }
        /* remove entry from database */
        foreach ($ARGS['selected_entries'] as $id)
        {
            if (!$this->database->remove("blog.${id}")) {
                /* entry does not exist */
                $YANA->report(new warning('ungueltige_eingabe'));
                return false;
            }
        } /* end for */
        /* commit changes */
        return $this->database->write();
    }


    /**
     * blog_default_new_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        default
     * Permission:  0
     * Templates:   BLOG_NEW_BLOG
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_default_new_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_default_new_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;
        $YANA->setVar('RSS_ACTION', 'blog_rss');

        /* do something */
        return true;
    }


    /**
     * blog_write_new_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        write
     * Permission:  0
     * Templates:   MESSAGE 
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_write_new_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_write_new_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;

        $newEntry = GuiCreator::getFormdata(GUI_NEW, $this->database->structure, 'blog');

        /* no data has been provided */
        if (empty($newEntry)) {
            $YANA->report(new Warning('ungueltige_eingabe'));
            return false;
        }

        /* insert new entry into table */
        if (!$this->database->insert("blog.*", $newEntry)) {
            $YANA->report(new Warning('ungueltige_eingabe'));
            return false;
        } else {
            return $this->database->write();
        }
    }


    /**
     * blog_read_search_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        read
     * Permission:  0
     * Templates:   BLOG_SEARCH_BLOG
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_read_search_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_read_search_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;
        $YANA->setVar('RSS_ACTION', 'blog_rss');

        return true;
    }


    /**
     * blog_read_read_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        read
     * Permission:  0
     * Templates:   BLOG_READ_BLOG
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_read_read_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_read_read_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;
        $YANA->setVar('RSS_ACTION', 'blog_rss');

        /* do something */
        return true;
    }


    /**
     * blog_read_read_seperated_blog
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        read
     * Permission:  0
     * Templates:   BLOG_READ_SEPERATED_BLOG
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_read_read_seperated_blog()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_read_read_seperated_blog ($ARGS)
    {
        /* check input data */
        assert('is_array($ARGS);');
        settype($ARGS, "array");

        /* global variables */
        global $YANA;
        $YANA->setVar('RSS_ACTION', 'blog_rss');
        if (isset($ARGS['blog_id']) && is_numeric($ARGS['blog_id'])) {
            $id = (int) $ARGS['blog_id'];
            $YANA->setVar('WHERE', "blog_id=$id");
        }
        return true;
    }


    /**
     * blog_rss
     *
     * returns bool(true) on success and bool(false) on error
     *
     * Type:        read
     * Permission:  0
     * Templates:   NULL
     *
     * @access  public
     * @return  bool
     * @name    plugin_blog::blog_rss()
     * @param   array  $ARGS  array of params passed to the function
     */
    function blog_rss ($ARGS)
    {
        if (!class_exists('RSS')) {
            trigger_error("RSS wrapper class not found. Unable to proceed.", E_USER_ERROR);
            return false;
        } else {
            /* get entries from database */
            $query = array(
            'key' => 'blog.*',
            'order_by' => 'blog_created',
            'desc' => true,
            'limit' => 10
            );
            $rows = $this->database->get($query);
            /* create RSS feed */
            $rss = new RSS();
            /* set description */
            $rss->description = 'the 10 most recent blog entries';
            foreach ($rows as $row)
            {
                $item = new RSSitem();
                /* 1) process title */
                $item->title = $row['BLOG_TITLE'];
                /* 2) process link */
                $id = $row['BLOG_ID'];
                $item->link = DisplayUtility::url("action=blog_read_read_seperated_blog&blog_id=$id", true);
                $item->link = str_replace(session_name()."=".session_id(), '', $item->link);
                /* 3) process description */
                $item->description = $row['BLOG_TEXT'];
                $item->description = DisplayUtility::embeddedTags($item->description);
                $item->description = DisplayUtility::smilies($item->description);
                $item->description = strip_tags($item->description);
                if (strlen($item->description) > 500) {
                    $item->description = substr($item->description, 0, 496).' ...';
                }
                /* 4) process pubDate */
                $item->pubDate = $row['BLOG_CREATED'];
                if (is_numeric($item->pubDate)) {
                    $item->pubDate = date('r', $item->pubDate);
                }
                $rss->addItem($item);
            } /* end foreach */
            print utf8_encode($rss->toString());
            exit(0);
            return true;
        }
    }

/* END auto-generated Event-handlers */

/* BEGIN auto-generated functions */

    /* NOTE:
     * By convention you can hide any member function from the plugin manager
     * by using an underscore '_' as the first character of the function's name.
     * This results in: any such function (event) can not be triggered directly
     * by the user through pointing the "action" parameter in the url to that
     * function name, like: index.php?action=function_name
     *
     * (Using underscores is a common PHP4 notation for "private")
     *
     * This also means, if for some reason you need to create a public event handler
     * whose name somehow has to begin with an underscore, you need to declare this
     * within the class' default event handler.
     */

    /**
     * remove tags from user form data
     *
     * @static
     * @access  private
     * @name    plugin_blog::_untaintInput()
     * @param   array   $input  associative array containing user form data
     *
     * @ignore
     */
    function _untaintInput(&$input)
    {
        if (is_array($input)) {
            foreach ($input as $a => $b)
            {
                $input[$a] = untaintInput($b, "string", 0, YANA_ESCAPE_USERTEXT);
            }
        }
    }

/* END auto-generated functions */

}
?>
