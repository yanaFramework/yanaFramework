CREATE TABLE "project" (
	"project_id" INTEGER NOT NULL,
	"project_name" VARCHAR2(255 CHAR) NOT NULL,
	"project_created" INTEGER NOT NULL,
	"project_loan" NUMBER(5,2) NOT NULL,
	"project_description" CLOB,
	"project_file" VARCHAR2(128 CHAR),
	"profile_id" VARCHAR2(128 CHAR) NOT NULL,
	CONSTRAINT "project_pk" PRIMARY KEY ("project_id")
);CREATE TABLE "effort" (
	"effort_id" INTEGER NOT NULL,
	"project_id" CLOB NOT NULL,
	"effort_user" VARCHAR2(100 CHAR) NOT NULL DEFAULT '%SESSION_USER_ID%',
	"effort_short" VARCHAR2(50 CHAR) NOT NULL,
	"effort_date" INTEGER NOT NULL,
	"effort_duration" NUMBER(4,2) NOT NULL,
	"effort_description" CLOB,
	"effort_state" NUMBER(1) DEFAULT 0,
	"profile_id" VARCHAR2(128 CHAR) NOT NULL,
	CONSTRAINT "effort_pk" PRIMARY KEY ("effort_id")
);CREATE SEQUENCE "project_sq0";CREATE OR REPLACE TRIGGER "project_project_id_inc"
	BEFORE INSERT ON "project"
	FOR EACH ROW BEGIN
	SELECT "project_project_id_sq".nextval INTO :new."project_id" FROM dual;
	END;
;COMMENT ON COLUMN "project"."project_name" IS '%LANGUAGE.PRJ.NAME%';COMMENT ON COLUMN "project"."project_created" IS '%LANGUAGE.PRJ.CREATED%';COMMENT ON COLUMN "project"."project_loan" IS '%LANGUAGE.PRJ.LOAN%';COMMENT ON COLUMN "project"."project_description" IS '%LANGUAGE.PRJ.DESC%';COMMENT ON COLUMN "project"."project_file" IS '%LANGUAGE.PRJ.FILE%';CREATE SEQUENCE "effort_sq0";CREATE OR REPLACE TRIGGER "effort_effort_id_inc"
	BEFORE INSERT ON "effort"
	FOR EACH ROW BEGIN
	SELECT "effort_effort_id_sq".nextval INTO :new."effort_id" FROM dual;
	END;
;COMMENT ON COLUMN "effort"."project_id" IS '%LANGUAGE.PRJ.ID%';COMMENT ON COLUMN "effort"."effort_user" IS '%LANGUAGE.PRJ.USER%';COMMENT ON COLUMN "effort"."effort_short" IS '%LANGUAGE.PRJ.SHORT%';COMMENT ON COLUMN "effort"."effort_date" IS '%LANGUAGE.PRJ.DATE%';COMMENT ON COLUMN "effort"."effort_duration" IS '%LANGUAGE.PRJ.DUR%';COMMENT ON COLUMN "effort"."effort_description" IS '%LANGUAGE.PRJ.DESC%';COMMENT ON COLUMN "effort"."effort_state" IS '%LANGUAGE.PRJ.STATE%';ALTER TABLE "effort" ADD CONSTRAINT "effort_fk0" FOREIGN KEY ("project_id") REFERENCES "project" ("project_id");