CREATE TABLE "microsummary" (
	"microsummary_id" VARCHAR2(32 CHAR) NOT NULL,
	"microsummary_text" CLOB NOT NULL,
	CONSTRAINT "microsummary_pk" PRIMARY KEY ("microsummary_id")
);COMMENT ON COLUMN "microsummary"."microsummary_id" IS 'ID';COMMENT ON COLUMN "microsummary"."microsummary_text" IS 'Microsummary';