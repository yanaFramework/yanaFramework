CREATE TABLE "log" (
	"log_id" INTEGER NOT NULL,
	"log_action" VARCHAR2(200 CHAR) NOT NULL,
	"log_ip" VARCHAR2(15 CHAR) NOT NULL,
	"log_user" VARCHAR2(128 CHAR) NOT NULL DEFAULT '%SESSION_USER_ID%',
	"log_time" INTEGER NOT NULL,
	"log_message" CLOB NOT NULL,
	"log_data" CLOB,
	CONSTRAINT "log_pk" PRIMARY KEY ("log_id")
);CREATE SEQUENCE "log_sq0";CREATE OR REPLACE TRIGGER "log_log_id_inc"
	BEFORE INSERT ON "log"
	FOR EACH ROW BEGIN
	SELECT "log_log_id_sq".nextval INTO :new."log_id" FROM dual;
	END;
;COMMENT ON COLUMN "log"."log_id" IS 'ID';COMMENT ON COLUMN "log"."log_action" IS 'Action';COMMENT ON COLUMN "log"."log_ip" IS 'IP';COMMENT ON COLUMN "log"."log_user" IS 'User';COMMENT ON COLUMN "log"."log_time" IS 'Date';COMMENT ON COLUMN "log"."log_message" IS 'Description';COMMENT ON COLUMN "log"."log_data" IS 'Data';