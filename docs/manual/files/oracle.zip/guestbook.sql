CREATE TABLE "guestbook" (
	"guestbook_id" INTEGER NOT NULL,
	"profile_id" VARCHAR2(128 CHAR) NOT NULL,
	"guestbook_ip" VARCHAR2(15 CHAR) NOT NULL,
	"guestbook_name" VARCHAR2(128 CHAR) NOT NULL,
	"guestbook_message" CLOB NOT NULL,
	"guestbook_mail" VARCHAR2(255 CHAR),
	"guestbook_hometown" VARCHAR2(100 CHAR),
	"guestbook_homepage" VARCHAR2(512 CHAR),
	"guestbook_messenger" VARCHAR2(255 CHAR),
	"guestbook_msgtyp" CLOB,
	"guestbook_opinion" CLOB,
	"guestbook_date" INTEGER NOT NULL,
	"guestbook_comment" CLOB,
	"guestbook_is_registered" INTEGER DEFAULT '0',
	CONSTRAINT "guestbook_pk" PRIMARY KEY ("guestbook_id")
);CREATE SEQUENCE "guestbook_sq0";CREATE OR REPLACE TRIGGER "guestbook_guestbook_id_inc"
	BEFORE INSERT ON "guestbook"
	FOR EACH ROW BEGIN
	SELECT "guestbook_guestbook_id_sq".nextval INTO :new."guestbook_id" FROM dual;
	END;
;COMMENT ON COLUMN "guestbook"."guestbook_name" IS '%LANGUAGE.21%';COMMENT ON COLUMN "guestbook"."guestbook_message" IS '%LANGUAGE.8%';COMMENT ON COLUMN "guestbook"."guestbook_mail" IS 'E-Mail';COMMENT ON COLUMN "guestbook"."guestbook_hometown" IS '%LANGUAGE.4%';COMMENT ON COLUMN "guestbook"."guestbook_homepage" IS '%LANGUAGE.2%';COMMENT ON COLUMN "guestbook"."guestbook_messenger" IS 'Messenger';COMMENT ON COLUMN "guestbook"."guestbook_msgtyp" IS 'Typ';COMMENT ON COLUMN "guestbook"."guestbook_opinion" IS '%LANGUAGE.RATE_0%';COMMENT ON COLUMN "guestbook"."guestbook_date" IS '%LANGUAGE.DATE_TIME%';COMMENT ON COLUMN "guestbook"."guestbook_comment" IS '%LANGUAGE.5%';INSERT INTO "guestbook" ("guestbook_name", "guestbook_message", "profile_id", "guestbook_ip", "guestbook_date", "guestbook_hometown", "guestbook_homepage", "guestbook_id") VALUES ('Tom', '[h]Herzlich Willkommen![/h] Das ist dein neues G&auml;stebuch mit dem Besucher deiner Webseite dir Nachrichten hinterlassen k�nnen. Dir stehen [color=red]viele Funktionen[/color] zur Verf�gung, wie Smilies :bigsmile: oder [b][big]Text[/big][i]format[small]ierung[/small][/i][/b].[br] [br]Ausserdem besitzt dieses G&auml;stebuch eine [mark]Multi-User Umgebung[/mark]. Alle deine Freunde k&ouml;nnen bei dir ein eigenes G&auml;stebuch bekommen.[br] [br]Du hast eine Mailbenachrichtigung bei neuen Eintr&auml;gen und die M�glichkeit [mark]individuelle Skins[/mark] zu gestalten.[br] [br] [b]:problem: Ein kleines Geheimnis:[/b][hide] Auf unserer Homepage gibt es kostenlos Plugins zum Download, mit denen man sein G�stebuch mit neuen Funktionen aufpeppen kann. F�r Communities gibt es zum Beispiel eine Rechteverwaltung f�r angemeldete Nutzer und vieles mehr![/hide] [br] [c]:haus: kostenlose Updates findest du auf [url=www.yanaframework.net]unserer Homepage[/url][/c]', 'default', '127.0.0.1', '1142975124', 'Jena', 'www.yanaframework.net', 1);