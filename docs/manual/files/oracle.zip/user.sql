CREATE TABLE "usergroup" (
	"group_id" VARCHAR2(32 CHAR) NOT NULL,
	"group_value" INTEGER NOT NULL DEFAULT '0',
	"group_name" VARCHAR2(64 CHAR) NOT NULL,
	CONSTRAINT "usergroup_pk" PRIMARY KEY ("group_id")
);CREATE TABLE "user" (
	"user_id" VARCHAR2(32 CHAR) NOT NULL,
	"inserted" INTEGER NOT NULL,
	"modified" INTEGER,
	"user_pwd" VARCHAR2(128 CHAR) NOT NULL DEFAULT 'UNINITIALIZED',
	"user_mail" VARCHAR2(255 CHAR) NOT NULL,
	"user_gender" CLOB,
	"group_id" CLOB NOT NULL,
	"active" NUMBER(1) NOT NULL DEFAULT 1,
	"user_language" VARCHAR2(32 CHAR),
	"user_image" VARCHAR2(128 CHAR),
	"user_image_active" NUMBER(1) DEFAULT 0,
	"user_failure_count" INTEGER DEFAULT '0',
	"user_failure_time" INTEGER,
	"count_logins" INTEGER DEFAULT '0',
	"last_login" INTEGER,
	"user_description" CLOB,
	CONSTRAINT "user_pk" PRIMARY KEY ("user_id")
);CREATE TABLE "useraccess" (
	"access_id" INTEGER NOT NULL,
	"user_id" CLOB NOT NULL,
	"group_id" CLOB NOT NULL,
	"profile_id" VARCHAR2(32 CHAR) NOT NULL,
	CONSTRAINT "useraccess_pk" PRIMARY KEY ("access_id")
);CREATE TABLE "newuser" (
	"newuser_id" INTEGER NOT NULL,
	"newuser_key" CLOB NOT NULL,
	"newuser_mail" VARCHAR2(255 CHAR) NOT NULL,
	"newuser_name" VARCHAR2(32 CHAR) NOT NULL,
	"newuser_utc" INTEGER NOT NULL,
	"newuser_ip" VARCHAR2(15 CHAR) NOT NULL,
	CONSTRAINT "newuser_pk" PRIMARY KEY ("newuser_id")
);COMMENT ON COLUMN "user"."user_id" IS '%LANGUAGE.USER.OPTION.0%';COMMENT ON COLUMN "user"."user_mail" IS '%LANGUAGE.USER.OPTION.5%';COMMENT ON COLUMN "user"."user_gender" IS '%LANGUAGE.USER.OPTION.19%';COMMENT ON COLUMN "user"."group_id" IS '%LANGUAGE.USER.OPTION.1%';COMMENT ON COLUMN "user"."active" IS '%LANGUAGE.USER.OPTION.3%';COMMENT ON COLUMN "user"."user_image" IS '%LANGUAGE.USER.OPTION.6%';COMMENT ON COLUMN "user"."user_image_active" IS '%LANGUAGE.USER.24%';COMMENT ON COLUMN "user"."user_description" IS '%LANGUAGE.USER.OPTION.17%';ALTER TABLE "user" ADD CONSTRAINT "user_fk0" FOREIGN KEY ("group_id") REFERENCES "usergroup" ("group_id");CREATE SEQUENCE "useraccess_sq0";CREATE OR REPLACE TRIGGER "useraccess_access_id_inc"
	BEFORE INSERT ON "useraccess"
	FOR EACH ROW BEGIN
	SELECT "useraccess_access_id_sq".nextval INTO :new."access_id" FROM dual;
	END;
;COMMENT ON COLUMN "useraccess"."user_id" IS '%LANGUAGE.USER.OPTION.0%';COMMENT ON COLUMN "useraccess"."group_id" IS '%LANGUAGE.USER.OPTION.2%';COMMENT ON COLUMN "useraccess"."profile_id" IS '%LANGUAGE.PROFILE_ID%';ALTER TABLE "useraccess" ADD CONSTRAINT "useraccess_fk0" FOREIGN KEY ("group_id") REFERENCES "usergroup" ("group_id");ALTER TABLE "useraccess" ADD CONSTRAINT "useraccess_fk1" FOREIGN KEY ("user_id") REFERENCES "user" ("user_id");CREATE SEQUENCE "newuser_sq0";CREATE OR REPLACE TRIGGER "newuser_newuser_id_inc"
	BEFORE INSERT ON "newuser"
	FOR EACH ROW BEGIN
	SELECT "newuser_newuser_id_sq".nextval INTO :new."newuser_id" FROM dual;
	END;
;INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (-1, '%LANGUAGE.GROUPS.0%', 'BLOCKED');INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (0, '%LANGUAGE.GROUPS.1%', 'GUEST');INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (1, '%LANGUAGE.GROUPS.5%', 'REGISTERED');INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (30, '%LANGUAGE.GROUPS.2%', 'MOD');INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (75, '%LANGUAGE.GROUPS.3%', 'OWNER');INSERT INTO "usergroup" ("group_value", "group_name", "group_id") VALUES (100, '%LANGUAGE.GROUPS.4%', 'ADMIN');INSERT INTO "user" ("user_pwd", "group_id", "active", "inserted", "user_description", "last_login", "count_logins", "modified", "user_mail", "user_image_active", "user_id") VALUES ('UNINITIALIZED', 'ADMIN', 1, '1110324851', 'Das ist ein vordefiniertes Nutzerkonto f�r den Administrator des Programms.[br] [br][c]Dieses Konto kann nicht gel�scht werden.[/c]', '1110324851', 1, '1110324851', 'mail@domain.tld', 0, 'ADMINISTRATOR');