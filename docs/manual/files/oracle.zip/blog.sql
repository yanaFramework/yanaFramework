CREATE TABLE "blog" (
	"blog_id" INTEGER NOT NULL,
	"blog_title" VARCHAR2(80 CHAR) NOT NULL,
	"blog_text" CLOB NOT NULL,
	"blog_created" INTEGER NOT NULL,
	"blog_author" VARCHAR2(80 CHAR),
	"profile_id" VARCHAR2(128 CHAR) NOT NULL,
	CONSTRAINT "blog_pk" PRIMARY KEY ("blog_id")
);CREATE TABLE "blogcmt" (
	"blogcmt_id" INTEGER NOT NULL,
	"blog_id" CLOB NOT NULL,
	"blogcmt_text" CLOB NOT NULL,
	"blogcmt_created" INTEGER NOT NULL,
	"blogcmt_author" VARCHAR2(80 CHAR),
	"profile_id" VARCHAR2(128 CHAR) NOT NULL,
	CONSTRAINT "blogcmt_pk" PRIMARY KEY ("blogcmt_id")
);CREATE SEQUENCE "blog_sq0";CREATE OR REPLACE TRIGGER "blog_blog_id_inc"
	BEFORE INSERT ON "blog"
	FOR EACH ROW BEGIN
	SELECT "blog_blog_id_sq".nextval INTO :new."blog_id" FROM dual;
	END;
;COMMENT ON COLUMN "blog"."blog_title" IS '%LANGUAGE.BLOG.TITLE%';COMMENT ON COLUMN "blog"."blog_text" IS '%LANGUAGE.BLOG.TEXT%';COMMENT ON COLUMN "blog"."blog_created" IS '%LANGUAGE.BLOG.CREATED%';COMMENT ON COLUMN "blog"."blog_author" IS '%LANGUAGE.BLOG.NAME%';CREATE SEQUENCE "blogcmt_sq0";CREATE OR REPLACE TRIGGER "blogcmt_blogcmt_id_inc"
	BEFORE INSERT ON "blogcmt"
	FOR EACH ROW BEGIN
	SELECT "blogcmt_blogcmt_id_sq".nextval INTO :new."blogcmt_id" FROM dual;
	END;
;COMMENT ON COLUMN "blogcmt"."blog_id" IS '%LANGUAGE.BLOG.TOPIC%';COMMENT ON COLUMN "blogcmt"."blogcmt_text" IS '%LANGUAGE.BLOG.TEXT%';COMMENT ON COLUMN "blogcmt"."blogcmt_created" IS '%LANGUAGE.BLOG.CREATED%';COMMENT ON COLUMN "blogcmt"."blogcmt_author" IS '%LANGUAGE.BLOG.NAME%';ALTER TABLE "blogcmt" ADD CONSTRAINT "blogcmt_fk0" FOREIGN KEY ("blog_id") REFERENCES "blog" ("blog_id");