CREATE SEQUENCE effort_effort_id_sq INCREMENT 1;CREATE SEQUENCE project_project_id_sq INCREMENT 1;CREATE TABLE "project" (
	"project_id" integer NOT NULL DEFAULT nextval('project_project_id_sq') PRIMARY KEY,
	"project_name" varchar(255) NOT NULL,
	"project_created" integer NOT NULL,
	"project_loan" double precision NOT NULL,
	"project_description" text,
	"project_file" varchar(128),
	"profile_id" varchar(128) NOT NULL
);CREATE TABLE "effort" (
	"effort_id" integer NOT NULL DEFAULT nextval('effort_effort_id_sq') PRIMARY KEY,
	"project_id" integer NOT NULL,
	"effort_user" varchar(100) NOT NULL DEFAULT '%SESSION_USER_ID%',
	"effort_short" varchar(50) NOT NULL,
	"effort_date" integer NOT NULL,
	"effort_duration" double precision NOT NULL,
	"effort_description" text,
	"effort_state" boolean DEFAULT false,
	"profile_id" varchar(128) NOT NULL
);COMMENT ON COLUMN "project"."project_name" IS '%LANGUAGE.PRJ.NAME%';COMMENT ON COLUMN "project"."project_created" IS '%LANGUAGE.PRJ.CREATED%';COMMENT ON COLUMN "project"."project_loan" IS '%LANGUAGE.PRJ.LOAN%';COMMENT ON COLUMN "project"."project_description" IS '%LANGUAGE.PRJ.DESC%';COMMENT ON COLUMN "project"."project_file" IS '%LANGUAGE.PRJ.FILE%';ALTER TABLE "effort" ADD FOREIGN KEY ("project_id") REFERENCES "project";COMMENT ON COLUMN "effort"."project_id" IS '%LANGUAGE.PRJ.ID%';COMMENT ON COLUMN "effort"."effort_user" IS '%LANGUAGE.PRJ.USER%';COMMENT ON COLUMN "effort"."effort_short" IS '%LANGUAGE.PRJ.SHORT%';COMMENT ON COLUMN "effort"."effort_date" IS '%LANGUAGE.PRJ.DATE%';COMMENT ON COLUMN "effort"."effort_duration" IS '%LANGUAGE.PRJ.DUR%';COMMENT ON COLUMN "effort"."effort_description" IS '%LANGUAGE.PRJ.DESC%';COMMENT ON COLUMN "effort"."effort_state" IS '%LANGUAGE.PRJ.STATE%';