CREATE SEQUENCE guestbook_guestbook_id_sq INCREMENT 1;CREATE TABLE "guestbook" (
	"guestbook_id" integer NOT NULL DEFAULT nextval('guestbook_guestbook_id_sq') PRIMARY KEY,
	"profile_id" varchar(128) NOT NULL,
	"guestbook_ip" varchar(15) NOT NULL,
	"guestbook_name" varchar(128) NOT NULL,
	"guestbook_message" text NOT NULL,
	"guestbook_mail" varchar(255),
	"guestbook_hometown" varchar(100),
	"guestbook_homepage" varchar(512),
	"guestbook_messenger" varchar(255),
	"guestbook_msgtyp" text,
	"guestbook_opinion" text,
	"guestbook_date" integer NOT NULL,
	"guestbook_comment" text,
	"guestbook_is_registered" integer DEFAULT '0'
);COMMENT ON COLUMN "guestbook"."guestbook_name" IS '%LANGUAGE.21%';COMMENT ON COLUMN "guestbook"."guestbook_message" IS '%LANGUAGE.8%';COMMENT ON COLUMN "guestbook"."guestbook_mail" IS 'E-Mail';COMMENT ON COLUMN "guestbook"."guestbook_hometown" IS '%LANGUAGE.4%';COMMENT ON COLUMN "guestbook"."guestbook_homepage" IS '%LANGUAGE.2%';COMMENT ON COLUMN "guestbook"."guestbook_messenger" IS 'Messenger';COMMENT ON COLUMN "guestbook"."guestbook_msgtyp" IS 'Typ';COMMENT ON COLUMN "guestbook"."guestbook_opinion" IS '%LANGUAGE.RATE_0%';COMMENT ON COLUMN "guestbook"."guestbook_date" IS '%LANGUAGE.DATE_TIME%';COMMENT ON COLUMN "guestbook"."guestbook_comment" IS '%LANGUAGE.5%';INSERT INTO "guestbook" ("guestbook_name", "guestbook_message", "profile_id", "guestbook_ip", "guestbook_date", "guestbook_hometown", "guestbook_homepage", "guestbook_id") VALUES ('Tom', '[h]Herzlich Willkommen![/h] Das ist dein neues G&auml;stebuch mit dem Besucher deiner Webseite dir Nachrichten hinterlassen k�nnen. Dir stehen [color=red]viele Funktionen[/color] zur Verf�gung, wie Smilies :bigsmile: oder [b][big]Text[/big][i]format[small]ierung[/small][/i][/b].[br] [br]Ausserdem besitzt dieses G&auml;stebuch eine [mark]Multi-User Umgebung[/mark]. Alle deine Freunde k&ouml;nnen bei dir ein eigenes G&auml;stebuch bekommen.[br] [br]Du hast eine Mailbenachrichtigung bei neuen Eintr&auml;gen und die M�glichkeit [mark]individuelle Skins[/mark] zu gestalten.[br] [br] [b]:problem: Ein kleines Geheimnis:[/b][hide] Auf unserer Homepage gibt es kostenlos Plugins zum Download, mit denen man sein G�stebuch mit neuen Funktionen aufpeppen kann. F�r Communities gibt es zum Beispiel eine Rechteverwaltung f�r angemeldete Nutzer und vieles mehr![/hide] [br] [c]:haus: kostenlose Updates findest du auf [url=www.yanaframework.net]unserer Homepage[/url][/c]', 'default', '127.0.0.1', '1142975124', 'Jena', 'www.yanaframework.net', 1);