CREATE SEQUENCE blogcmt_blogcmt_id_sq INCREMENT 1;CREATE SEQUENCE blog_blog_id_sq INCREMENT 1;CREATE TABLE "blog" (
	"blog_id" integer NOT NULL DEFAULT nextval('blog_blog_id_sq') PRIMARY KEY,
	"blog_title" varchar(80) NOT NULL,
	"blog_text" text NOT NULL,
	"blog_created" integer NOT NULL,
	"blog_author" varchar(80),
	"profile_id" varchar(128) NOT NULL
);CREATE TABLE "blogcmt" (
	"blogcmt_id" integer NOT NULL DEFAULT nextval('blogcmt_blogcmt_id_sq') PRIMARY KEY,
	"blog_id" integer NOT NULL,
	"blogcmt_text" text NOT NULL,
	"blogcmt_created" integer NOT NULL,
	"blogcmt_author" varchar(80),
	"profile_id" varchar(128) NOT NULL
);COMMENT ON COLUMN "blog"."blog_title" IS '%LANGUAGE.BLOG.TITLE%';COMMENT ON COLUMN "blog"."blog_text" IS '%LANGUAGE.BLOG.TEXT%';COMMENT ON COLUMN "blog"."blog_created" IS '%LANGUAGE.BLOG.CREATED%';COMMENT ON COLUMN "blog"."blog_author" IS '%LANGUAGE.BLOG.NAME%';ALTER TABLE "blogcmt" ADD FOREIGN KEY ("blog_id") REFERENCES "blog";COMMENT ON COLUMN "blogcmt"."blog_id" IS '%LANGUAGE.BLOG.TOPIC%';COMMENT ON COLUMN "blogcmt"."blogcmt_text" IS '%LANGUAGE.BLOG.TEXT%';COMMENT ON COLUMN "blogcmt"."blogcmt_created" IS '%LANGUAGE.BLOG.CREATED%';COMMENT ON COLUMN "blogcmt"."blogcmt_author" IS '%LANGUAGE.BLOG.NAME%';