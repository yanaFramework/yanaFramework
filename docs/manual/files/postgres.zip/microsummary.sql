CREATE TABLE "microsummary" (
	"microsummary_id" varchar(32) NOT NULL PRIMARY KEY,
	"microsummary_text" text NOT NULL
);COMMENT ON COLUMN "microsummary"."microsummary_id" IS 'ID';COMMENT ON COLUMN "microsummary"."microsummary_text" IS 'Microsummary';