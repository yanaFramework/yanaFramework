CREATE SEQUENCE log_log_id_sq INCREMENT 1;CREATE TABLE "log" (
	"log_id" integer NOT NULL DEFAULT nextval('log_log_id_sq') PRIMARY KEY,
	"log_action" varchar(200) NOT NULL,
	"log_ip" varchar(15) NOT NULL,
	"log_user" varchar(128) NOT NULL DEFAULT '%SESSION_USER_ID%',
	"log_time" integer NOT NULL,
	"log_message" text NOT NULL,
	"log_data" text
);COMMENT ON COLUMN "log"."log_id" IS 'ID';COMMENT ON COLUMN "log"."log_action" IS 'Action';COMMENT ON COLUMN "log"."log_ip" IS 'IP';COMMENT ON COLUMN "log"."log_user" IS 'User';COMMENT ON COLUMN "log"."log_time" IS 'Date';COMMENT ON COLUMN "log"."log_message" IS 'Description';COMMENT ON COLUMN "log"."log_data" IS 'Data';