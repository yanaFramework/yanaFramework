CREATE TABLE [dbo].[project] (
	[project_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT project_pk PRIMARY KEY,
	[project_name] varchar(255) NOT NULL,
	[project_created] integer NOT NULL,
	[project_loan] float NOT NULL,
	[project_description] text NULL,
	[project_file] varchar(128) NULL,
	[profile_id] varchar(128) NOT NULL
);CREATE TABLE [dbo].[effort] (
	[effort_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT effort_pk PRIMARY KEY,
	[project_id] integer NOT NULL,
	[effort_user] varchar(100) NOT NULL DEFAULT '%SESSION_USER_ID%',
	[effort_short] varchar(50) NOT NULL,
	[effort_date] integer NOT NULL,
	[effort_duration] float NOT NULL,
	[effort_description] text NULL,
	[effort_state] bit NULL DEFAULT 0,
	[profile_id] varchar(128) NOT NULL
);ALTER TABLE [dbo].[effort] ADD CONSTRAINT effort_project_fk FOREIGN KEY (project_id) REFERENCES [dbo].[project];