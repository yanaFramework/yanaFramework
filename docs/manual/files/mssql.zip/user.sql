CREATE TABLE [dbo].[usergroup] (
	[group_id] varchar(32) NOT NULL CONSTRAINT usergroup_pk PRIMARY KEY,
	[group_value] integer NOT NULL DEFAULT '0',
	[group_name] varchar(64) NOT NULL
);CREATE TABLE [dbo].[user] (
	[user_id] varchar(32) NOT NULL CONSTRAINT user_pk PRIMARY KEY,
	[inserted] integer NOT NULL,
	[modified] integer NULL,
	[user_pwd] varchar(128) NOT NULL DEFAULT 'UNINITIALIZED',
	[user_mail] varchar(255) NOT NULL,
	[user_gender] text NULL,
	[group_id] varchar(32) NOT NULL,
	[active] bit NOT NULL DEFAULT 1,
	[user_language] varchar(32) NULL,
	[user_image] varchar(128) NULL,
	[user_image_active] bit NULL DEFAULT 0,
	[user_failure_count] integer NULL DEFAULT '0',
	[user_failure_time] integer NULL,
	[count_logins] integer NULL DEFAULT '0',
	[last_login] integer NULL,
	[user_description] text NULL
);CREATE TABLE [dbo].[useraccess] (
	[access_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT useraccess_pk PRIMARY KEY,
	[user_id] varchar(32) NOT NULL,
	[group_id] varchar(32) NOT NULL,
	[profile_id] varchar(32) NOT NULL
);CREATE TABLE [dbo].[newuser] (
	[newuser_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT newuser_pk PRIMARY KEY,
	[newuser_key] text NOT NULL,
	[newuser_mail] varchar(255) NOT NULL,
	[newuser_name] varchar(32) NOT NULL,
	[newuser_utc] integer NOT NULL,
	[newuser_ip] varchar(15) NOT NULL
);ALTER TABLE [dbo].[user] ADD CONSTRAINT user_usergroup_fk FOREIGN KEY (group_id) REFERENCES [dbo].[usergroup];ALTER TABLE [dbo].[useraccess] ADD CONSTRAINT useraccess_user_fk FOREIGN KEY (user_id) REFERENCES [dbo].[user];ALTER TABLE [dbo].[useraccess] ADD CONSTRAINT useraccess_usergroup_fk FOREIGN KEY (group_id) REFERENCES [dbo].[usergroup];INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (-1, '%LANGUAGE.GROUPS.0%', 'BLOCKED');INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (0, '%LANGUAGE.GROUPS.1%', 'GUEST');INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (1, '%LANGUAGE.GROUPS.5%', 'REGISTERED');INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (30, '%LANGUAGE.GROUPS.2%', 'MOD');INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (75, '%LANGUAGE.GROUPS.3%', 'OWNER');INSERT INTO [usergroup] ([group_value], [group_name], [group_id]) VALUES (100, '%LANGUAGE.GROUPS.4%', 'ADMIN');INSERT INTO [user] ([user_pwd], [group_id], [active], [inserted], [user_description], [last_login], [count_logins], [modified], [user_mail], [user_image_active], [user_id]) VALUES ('UNINITIALIZED', 'ADMIN', 1, '1110324851', 'Das ist ein vordefiniertes Nutzerkonto f�r den Administrator des Programms.[br] [br][c]Dieses Konto kann nicht gel�scht werden.[/c]', '1110324851', 1, '1110324851', 'mail@domain.tld', 0, 'ADMINISTRATOR');