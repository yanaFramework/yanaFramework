CREATE TABLE [dbo].[log] (
	[log_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT log_pk PRIMARY KEY,
	[log_action] varchar(200) NOT NULL,
	[log_ip] varchar(15) NOT NULL,
	[log_user] varchar(128) NOT NULL DEFAULT '%SESSION_USER_ID%',
	[log_time] integer NOT NULL,
	[log_message] text NOT NULL,
	[log_data] text NULL
);