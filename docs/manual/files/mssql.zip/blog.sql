CREATE TABLE [dbo].[blog] (
	[blog_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT blog_pk PRIMARY KEY,
	[blog_title] varchar(80) NOT NULL,
	[blog_text] text NOT NULL,
	[blog_created] integer NOT NULL,
	[blog_author] varchar(80) NULL,
	[profile_id] varchar(128) NOT NULL
);CREATE TABLE [dbo].[blogcmt] (
	[blogcmt_id] integer NOT NULL IDENTITY (1,1) CONSTRAINT blogcmt_pk PRIMARY KEY,
	[blog_id] integer NOT NULL,
	[blogcmt_text] text NOT NULL,
	[blogcmt_created] integer NOT NULL,
	[blogcmt_author] varchar(80) NULL,
	[profile_id] varchar(128) NOT NULL
);ALTER TABLE [dbo].[blogcmt] ADD CONSTRAINT blogcmt_blog_fk FOREIGN KEY (blog_id) REFERENCES [dbo].[blog];