CREATE TABLE [dbo].[microsummary] (
	[microsummary_id] varchar(32) NOT NULL CONSTRAINT microsummary_pk PRIMARY KEY,
	[microsummary_text] text NOT NULL
);