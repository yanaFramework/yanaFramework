CREATE TABLE log(
	log_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1, NO CACHE) CONSTRAINT log_pk PRIMARY KEY,
	log_action VARCHAR(200) NOT NULL,
	log_ip VARCHAR(15) NOT NULL,
	log_user VARCHAR(128) NOT NULL DEFAULT '%SESSION_USER_ID%',
	log_time INTEGER NOT NULL,
	log_message LONG VARCHAR NOT NULL,
	log_data LONG VARCHAR
);COMMENT ON log (log_id IS 'ID');COMMENT ON log (log_action IS 'Action');COMMENT ON log (log_ip IS 'IP');COMMENT ON log (log_user IS 'User');COMMENT ON log (log_time IS 'Date');COMMENT ON log (log_message IS 'Description');COMMENT ON log (log_data IS 'Data');