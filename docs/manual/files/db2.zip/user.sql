CREATE TABLE usergroup(
	group_id VARCHAR(32) NOT NULL CONSTRAINT usergroup_pk PRIMARY KEY,
	group_value INTEGER NOT NULL DEFAULT '0',
	group_name VARCHAR(64) NOT NULL
);CREATE TABLE user(
	user_id VARCHAR(32) NOT NULL CONSTRAINT user_pk PRIMARY KEY,
	inserted INTEGER NOT NULL,
	modified INTEGER,
	user_pwd VARCHAR(128) NOT NULL DEFAULT 'UNINITIALIZED',
	user_mail VARCHAR(255) NOT NULL,
	user_gender LONG VARCHAR,
	group_id VARCHAR(32) NOT NULL,
	active SMALLINT(1) NOT NULL DEFAULT 1,
	user_language VARCHAR(32),
	user_image VARCHAR(128),
	user_image_active SMALLINT(1) DEFAULT 0,
	user_failure_count INTEGER DEFAULT '0',
	user_failure_time INTEGER,
	count_logins INTEGER DEFAULT '0',
	last_login INTEGER,
	user_description LONG VARCHAR
);CREATE TABLE useraccess(
	access_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1, NO CACHE) CONSTRAINT useraccess_pk PRIMARY KEY,
	user_id VARCHAR(32) NOT NULL,
	group_id VARCHAR(32) NOT NULL,
	profile_id VARCHAR(32) NOT NULL
);CREATE TABLE newuser(
	newuser_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1, NO CACHE) CONSTRAINT newuser_pk PRIMARY KEY,
	newuser_key LONG VARCHAR NOT NULL,
	newuser_mail VARCHAR(255) NOT NULL,
	newuser_name VARCHAR(32) NOT NULL,
	newuser_utc INTEGER NOT NULL,
	newuser_ip VARCHAR(15) NOT NULL
);COMMENT ON user (user_id IS '%LANGUAGE.USER.OPTION.0%');COMMENT ON user (user_mail IS '%LANGUAGE.USER.OPTION.5%');COMMENT ON user (user_gender IS '%LANGUAGE.USER.OPTION.19%');COMMENT ON user (group_id IS '%LANGUAGE.USER.OPTION.1%');COMMENT ON user (active IS '%LANGUAGE.USER.OPTION.3%');COMMENT ON user (user_image IS '%LANGUAGE.USER.OPTION.6%');COMMENT ON user (user_image_active IS '%LANGUAGE.USER.24%');COMMENT ON user (user_description IS '%LANGUAGE.USER.OPTION.17%');ALTER TABLE user ADD CONSTRAINT user_fk_0 FOREIGN KEY (group_id) REFERENCES usergroup;COMMENT ON useraccess (user_id IS '%LANGUAGE.USER.OPTION.0%');COMMENT ON useraccess (group_id IS '%LANGUAGE.USER.OPTION.2%');COMMENT ON useraccess (profile_id IS '%LANGUAGE.PROFILE_ID%');ALTER TABLE useraccess ADD CONSTRAINT useraccess_fk_0 FOREIGN KEY (group_id) REFERENCES usergroup;ALTER TABLE useraccess ADD CONSTRAINT useraccess_fk_1 FOREIGN KEY (user_id) REFERENCES user;INSERT INTO usergroup (group_value, group_name, group_id) VALUES (-1, '%LANGUAGE.GROUPS.0%', 'BLOCKED');INSERT INTO usergroup (group_value, group_name, group_id) VALUES (0, '%LANGUAGE.GROUPS.1%', 'GUEST');INSERT INTO usergroup (group_value, group_name, group_id) VALUES (1, '%LANGUAGE.GROUPS.5%', 'REGISTERED');INSERT INTO usergroup (group_value, group_name, group_id) VALUES (30, '%LANGUAGE.GROUPS.2%', 'MOD');INSERT INTO usergroup (group_value, group_name, group_id) VALUES (75, '%LANGUAGE.GROUPS.3%', 'OWNER');INSERT INTO usergroup (group_value, group_name, group_id) VALUES (100, '%LANGUAGE.GROUPS.4%', 'ADMIN');INSERT INTO user (user_pwd, group_id, active, inserted, user_description, last_login, count_logins, modified, user_mail, user_image_active, user_id) VALUES ('UNINITIALIZED', 'ADMIN', 1, '1110324851', 'Das ist ein vordefiniertes Nutzerkonto f�r den Administrator des Programms.[br] [br][c]Dieses Konto kann nicht gel�scht werden.[/c]', '1110324851', 1, '1110324851', 'mail@domain.tld', 0, 'ADMINISTRATOR');