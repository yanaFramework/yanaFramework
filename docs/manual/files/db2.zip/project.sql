CREATE TABLE project(
	project_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1, NO CACHE) CONSTRAINT project_pk PRIMARY KEY,
	project_name VARCHAR(255) NOT NULL,
	project_created INTEGER NOT NULL,
	project_loan float(5,2) NOT NULL,
	project_description LONG VARCHAR,
	project_file VARCHAR(128),
	profile_id VARCHAR(128) NOT NULL
);CREATE TABLE effort(
	effort_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1, NO CACHE) CONSTRAINT effort_pk PRIMARY KEY,
	project_id INTEGER NOT NULL,
	effort_user VARCHAR(100) NOT NULL DEFAULT '%SESSION_USER_ID%',
	effort_short VARCHAR(50) NOT NULL,
	effort_date INTEGER NOT NULL,
	effort_duration float(4,2) NOT NULL,
	effort_description LONG VARCHAR,
	effort_state SMALLINT(1) DEFAULT 0,
	profile_id VARCHAR(128) NOT NULL
);COMMENT ON project (project_name IS '%LANGUAGE.PRJ.NAME%');COMMENT ON project (project_created IS '%LANGUAGE.PRJ.CREATED%');COMMENT ON project (project_loan IS '%LANGUAGE.PRJ.LOAN%');COMMENT ON project (project_description IS '%LANGUAGE.PRJ.DESC%');COMMENT ON project (project_file IS '%LANGUAGE.PRJ.FILE%');COMMENT ON effort (project_id IS '%LANGUAGE.PRJ.ID%');COMMENT ON effort (effort_user IS '%LANGUAGE.PRJ.USER%');COMMENT ON effort (effort_short IS '%LANGUAGE.PRJ.SHORT%');COMMENT ON effort (effort_date IS '%LANGUAGE.PRJ.DATE%');COMMENT ON effort (effort_duration IS '%LANGUAGE.PRJ.DUR%');COMMENT ON effort (effort_description IS '%LANGUAGE.PRJ.DESC%');COMMENT ON effort (effort_state IS '%LANGUAGE.PRJ.STATE%');ALTER TABLE effort ADD CONSTRAINT effort_fk_0 FOREIGN KEY (project_id) REFERENCES project;