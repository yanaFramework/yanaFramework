CREATE TABLE microsummary(
	microsummary_id VARCHAR(32) NOT NULL CONSTRAINT microsummary_pk PRIMARY KEY,
	microsummary_text LONG VARCHAR NOT NULL
);COMMENT ON microsummary (microsummary_id IS 'ID');COMMENT ON microsummary (microsummary_text IS 'Microsummary');